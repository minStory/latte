package com.cinema.model;

public class MyTheater {
	private int my_theater_no;
	private String my_theater_member_no;
	private String my_theater_location;
	
	public int getMy_theater_no() {
		return my_theater_no;
	}
	public void setMy_theater_no(int my_theater_no) {
		this.my_theater_no = my_theater_no;
	}
	public String getMy_theater_member_no() {
		return my_theater_member_no;
	}
	public void setMy_theater_member_no(String my_theater_member_no) {
		this.my_theater_member_no = my_theater_member_no;
	}
	public String getMy_theater_location() {
		return my_theater_location;
	}
	public void setMy_theater_location(String my_theater_location) {
		this.my_theater_location = my_theater_location;
	}
}
