package com.cinema.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;

import com.cinema.model.AdminDTO;
import com.cinema.model.MemberDTO;

public class JsonObjectAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatterHour = DateTimeFormatter.ofPattern("hh");
		DateTimeFormatter formatterMinute = DateTimeFormatter.ofPattern("MM");
		DateTimeFormatter formatterSecond = DateTimeFormatter.ofPattern("ss");
		String formattedHour = now.format(formatterHour);

		String formattedMinute = now.format(formatterMinute);
		String formattedSecond = now.format(formatterSecond);

		long remainingTime = 0L;
		long remainingHour = 0L;
		long remainingMinute = 0L;

		System.out.println(request.getSession(false));
		
		HttpSession session = null;
		
		if (request.getSession(false) != null) {
			session = request.getSession(false);

			MemberDTO mDto = null;
			AdminDTO aDto = null;

			if (session.getAttribute("dto") != null) {
				if (session.getAttribute("no").equals("M")) {
					mDto = (MemberDTO) session.getAttribute("dto");
				} else if (session.getAttribute("no").equals("A")) {
					aDto = (AdminDTO) session.getAttribute("dto");
				}

				if (mDto != null || aDto != null) {
					long creationTime = session.getCreationTime(); // 세션 생성 시간
					//System.out.println("creationTime = " + creationTime);
					int maxInactiveInterval = session.getMaxInactiveInterval(); // 세션 유효 시간 (초)
					//System.out.println("maxInactiveInterval = " + maxInactiveInterval);
					long currentTime = System.currentTimeMillis(); // 현재 시간
					//System.out.println("currentTime = " + currentTime);

					long elapsedTime = currentTime - creationTime; // 세션 경과 시간
					remainingTime = maxInactiveInterval - TimeUnit.MILLISECONDS.toSeconds(elapsedTime); // 남은 시간 (초)
					remainingHour = remainingTime / 60 < 10 ? remainingTime / 60 : remainingTime / 60;
					remainingMinute = remainingTime % 60 < 10 ? remainingTime % 60 : remainingTime % 60;
					System.out.println("remainingHour = " + remainingHour);
					System.out.println("remainingMinute = " + remainingMinute);

					if (remainingHour == 0 && remainingMinute == 0) {

						session.invalidate();
						
						PrintWriter w = response.getWriter();
						w.println("<script>");
						w.println("alert('세션 만료')");
						w.println("</script>");
						
					}
				}
			}
		}

		String sessionHour = remainingHour <= 0 ? "00" : remainingHour < 10 ? "0" + remainingHour : "" + remainingHour;
		String sessionMinute = remainingMinute <= 0 ? "00"
				: remainingMinute < 10 ? "0" + remainingMinute : "" + remainingMinute;

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("time", formattedHour + ":" + formattedMinute + ":" + formattedSecond);
		jsonObject.put("session", sessionHour + ":" + sessionMinute);

		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");

		PrintWriter w = response.getWriter();
		w.write(jsonObject.toJSONString());
		w.close();

		return null;
	}
}