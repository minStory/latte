// ------ 메인페이지 배경이미지 변경 메서드 ------
let img_idx = 1; // 시작 이미지 번호
const img_count = 4; // 총 이미지 개수
const img_second = 5000; // 이미지를 유지할 시간(millisecond)

// 다음 이미지로 변경
function showNextImage() {
	const header_image = document.getElementsByClassName("header-image")[0];
    
    // 현재 이미지 제거
    header_image.classList.remove(`header-bg${img_idx}`);
    
    img_idx++;
    if (img_idx > img_count) {
        img_idx = 1;
    }
    // 다음 이미지 추가
    header_image.classList.add(`header-bg${img_idx}`);
    
    // 조건 만족 시 함수 종료
    if (img_idx > img_count) {
        img_idx = 1;
        return true;
    }
}

// 이전 이미지로 변경
function showPreviousImage(){
	const header_image = document.getElementsByClassName("header-image")[0];
    
    // 현재 이미지 제거
    header_image.classList.remove(`header-bg${img_idx}`);
    
    img_idx--;
    if (img_idx < 1) {
        img_idx = img_count;
    }
    // 이전 이미지 추가
    header_image.classList.add(`header-bg${img_idx}`);
    
    // 조건 만족 시 함수 종료
    if (img_idx < 1) {
        img_idx = img_count;
        return true;
    }
}
// ------ 메인페이지 배경이미지 변경 메서드 영역 end ------



// ------ 타이머 실행 영역 ------
const timers = [];
const timer1 = addTimer(showNextImage, img_second);
//const timer2 = addTimer(displayCurrentTime, 1000);
const timer3 = addTimer(fetchCurrentTime, 1000);
// ------ end ------



// ------ 타이머 조작 메서드 정의 영역 ------
// 타이머 추가
function addTimer(callback, interval){
	let timerId = setInterval(callback, interval);
	timers.push(timerId);
	return timerId;
}

// 특정 타이머를 중지
function stopTimer(timerID) {
    clearInterval(timerID);
    timers = timers.filter(id => id !== timerID);
}

// 모든 타이머를 중지
function stopAllTimers() {
    timers.forEach(timerID => clearInterval(timerID));
    timers = [];
}
// ------ end ------



// ------ 서버에서 JSON 객체 직접 호출 -------
function fetchCurrentTime() {
    fetch('json_object') // 서블릿 URL로 요청
        .then(response => response.json()) // 응답을 JSON 형태로 변환
        .then(data => {
        	document.getElementsByClassName("session-field")[0].innerText = data.session;
        })
        .catch(error => console.error('Error:', error));
}
// ------ end ------



// ------ 현재 시각 호출 메서드 (자바스크립트) ------
//function displayCurrentTime() {
//    let now = new Date();
//    let hours = now.getHours();
//    let minutes = now.getMinutes();
//    let seconds = now.getSeconds();
//
//    // 시간, 분, 초가 한 자리 숫자인 경우 앞에 0을 붙여 두 자리로 표시
//    hours = (hours < 10 ? "0" : "") + hours;
//    minutes = (minutes < 10 ? "0" : "") + minutes;
//    seconds = (seconds < 10 ? "0" : "") + seconds;
//
//    const currentTime = hours + ":" + minutes + ":" + seconds;
//
//    // 현재 시간을 해당 요소에 표시
//    document.getElementsByClassName("current-time")[0].innerText = currentTime;
//}
// ------ end ------



// ------ 회원가입 시 두 비밀번호가 일치하는지 확인하는 메서드 ------
function validatePwd(){
	if(myForm.pwd.value !== myForm.pwd_check.value){
		alert("비밀번호를 확인해주세요!");
		return false;
	}
}
// ------ end ------



// ------ 로그아웃 버튼을 클릭하면 확인창을 표시할 메서드 ------
function confirmLogout() {
    if (confirm("로그아웃하시겠습니까?")) {
        window.location.href = "logout";
    } else {
        return false;
    }
}
// ------ end ------