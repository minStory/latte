document.addEventListener("DOMContentLoaded", () => {
	
	const a = document.getElementsByClassName("a")[0];
	const b = document.getElementsByClassName("b")[0];
	const c = document.getElementsByClassName("c")[0];
	const d = document.getElementsByClassName("d")[0];
	
	const mypage_top_menu_tab = Array.from(document.getElementsByClassName("mypage_top_menu_tab")[0].children);

	if(window.location.href.includes("coupon")){
		a.style.display = "none";
		c.style.display = "none";
		d.style.display = "none";
		mypage_top_menu_tab[1].classList.add("bar");
	}else if(window.location.href.includes("inquiry")){
		a.style.display = "none";
		b.style.display = "none";
		d.style.display = "none";
		mypage_top_menu_tab[2].classList.add("bar");
	}else if(window.location.href.includes("info")){
		b.style.display = "none";
		c.style.display = "none";
		d.style.display = "none";
		mypage_top_menu_tab[3].classList.add("bar");
	}else{
		b.style.display = "none";
		c.style.display = "none";
		d.style.display = "none";
		mypage_top_menu_tab[0].classList.add("bar");
	}
	
	
	mypage_top_menu_tab.forEach((li, idx) => {
		li.addEventListener("click", () => {
			mypage_top_menu_tab.forEach((li) => {
				li.classList.remove("bar");
			});
			
			if(idx === 0){
				a.style.display = "block";
				b.style.display = "none";
				c.style.display = "none";
				d.style.display = "none";
				li.classList.add("bar");
				window.history.replaceState({}, document.title, window.location.pathname);
			}else if(idx === 1){
				a.style.display = "none";
				b.style.display = "block";
				c.style.display = "none";
				d.style.display = "none";
				li.classList.add("bar");
				window.history.replaceState({}, document.title, '?b');
			}else if(idx === 2){
				a.style.display = "none";
				b.style.display = "none";
				c.style.display = "block";
				d.style.display = "none";
				li.classList.add("bar");
				window.history.replaceState({}, document.title, '?c');
			}else if(idx === 3 ){
				a.style.display = "none";
				b.style.display = "none";
				c.style.display = "none";
				d.style.display = "block";
				li.classList.add("bar");
				window.history.replaceState({}, document.title, '?d');
			}
		});
	});
});
// ------ DOMContentLoaded end ------
		
const btn = Array.from(document.getElementsByClassName("ticket-btn"));
const content = Array.from(document.getElementsByClassName("mypage-ticket"));

content.forEach((li) => {
	li.style.display = "none";
})

btn.forEach((btn_li, btn_idx) => {
	btn_li.addEventListener("click", () => {
		content.forEach((content_li, content_idx) => {
			if(btn_idx === content_idx){
				if(content_li.style.display === "none"){
					content_li.style.display = "block";
				}else{
					content_li.style.display = "none";
				}
			}
		})
	})
});