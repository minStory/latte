// document.addEventListener("DOMContentLoaded", function () {
//   const parentElement = document.querySelector(".header-menu ul");

//   const childElements = parentElement.children;

//   for (let i = childElements.length - 1; i > 0; i--) {
//     const span = document.createElement("span");
//     span.style.borderLeft = "1px solid black";
//     span.style.height = "14px";
//     span.style.margin = "0 10px";

//     parentElement.insertBefore(span, childElements[i]);
//   }
// });
