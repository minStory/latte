package com.cinema.action.customer;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cinema.action.Action;
import com.cinema.action.ActionForward;
import com.cinema.model.InquiryHistoryDTO;
import com.cinema.model.LatteDAO;
import com.cinema.model.MemberDTO;

public class CustomerInsertInquiryAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		MemberDTO mDto = (MemberDTO) session.getAttribute("dto");
		String writer_no = mDto.getMember_no();
		String writer_id = mDto.getMember_id();

		String type = request.getParameter("type");
		String title = request.getParameter("title");
		String content = request.getParameter("content");

		System.out.println(type);
		System.out.println(title);
		System.out.println(content);
		System.out.println(writer_no);
		System.out.println(writer_id);

		InquiryHistoryDTO dto = new InquiryHistoryDTO();
		dto.setInquiry_history_type(type);
		dto.setInquiry_history_title(title);
		dto.setInquiry_history_content(content);
		dto.setInquiry_history_writer_no(writer_no);
		dto.setInquiry_history_writer_id(writer_id);
		dto.setInquiry_history_file("파일경로");

		LatteDAO dao = LatteDAO.getInstance();
		int check = dao.insertInquiry(dto);

		PrintWriter out = response.getWriter();

		if (check > 0) {
			out.println("<script>");
			out.println("alert('추가 성공!!')");
			out.println("location.href = 'main'");
			out.println("</script>");
			out.close();
		} else {
			out.println("<script>");
			out.println("alert('추가 실패!!')");
			out.println("history.back()'");
			out.println("</script>");
			out.close();
		}
		return null;
	}
}
