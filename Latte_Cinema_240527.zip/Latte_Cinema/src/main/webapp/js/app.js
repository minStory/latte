// 페이지 로드 시 실행되는 코드
document.addEventListener("DOMContentLoaded", () => {
	
	// ------ 메인페이지를 제외한 페이지의 헤더 디자인 변경 ------
	if(!window.location.href.includes("main")){
		const header = document.getElementsByClassName("header")[0];
		const header_image = document.getElementsByClassName("header-image")[0];
		const header_background = document.getElementsByClassName("header-background")[0];
		const header_bottom_background = document.getElementsByClassName("header-bottom-background")[0];
		const header_top = document.getElementsByClassName("header-top")[0];
		const header_top_logo = document.getElementsByClassName("header-top-logo")[0];
		const header_lnb = document.getElementsByClassName("header-lnb")[0];
		const btn_facebook = document.getElementsByClassName("btn-facebook")[0];
		const btn_youtube = document.getElementsByClassName("btn-youtube")[0];
		const btn_instagram = document.getElementsByClassName("btn-instagram")[0];
		const btn_signup = document.getElementsByClassName("btn-signup")[0];
		const btn_reserve = document.getElementsByClassName("btn-reserve")[0];
		
		header.classList.add("header-invert");
		header_image.classList.add("header-image-invert");
		header_background.classList.add("header-background-invert");
		header_bottom_background.classList.add("header-bottom-background-invert");
		header_top.classList.add("header-top-invert");
		btn_facebook.classList.add("btn-facebook-invert");
		btn_youtube.classList.add("btn-youtube-invert");
		btn_instagram.classList.add("btn-instagram-invert");
		btn_signup.classList.add("btn-signup-invert");
		btn_reserve.classList.add("btn-reserve-invert");
		header_top_logo.classList.add("header-top-logo-invert");
	}
	// ------ end ------
	
	// ------ 헤더의 lnb를 나타내는 메서드 ------
	const gnb = Array.from(document.getElementsByClassName("header-gnb-list")[0].children);
	const lnb = Array.from(document.getElementsByClassName("header-lnb")[0].children)
	const lnb_background = document.getElementsByClassName("header-lnb")[0];
	
	gnb.forEach((gnb_li, gnb_idx) => {
		gnb_li.addEventListener("mouseover", () => {
			lnb_background.style.display = "block";
			
			lnb.forEach((lnb_li, lnb_idx) => {
				if(gnb_idx === lnb_idx){
					lnb_li.style.display = "flex";
				}else{
					lnb_li.style.display = "none";
				}
			})
		})
	    lnb_background.addEventListener("mouseover", () => {
	        lnb_background.style.display = "block";
	    });
	
	    lnb.forEach((lnb_li) => {
	        lnb_li.addEventListener("mouseout", () => {
	            lnb_background.style.display = "none";
	        });
	    });
	
		// 마우스를 뗄 때 lnb_background의 display를 none으로 설정
	    gnb_li.addEventListener("mouseout", () => {
	        lnb_background.style.display = "none";
	    });
	});
	// ------ end ------
	
	// ------ 헤더의 2번째 lnb를 나타내는 메서드 ------
	const lnb_cinema = Array.from(document.getElementsByClassName("header-lnb-cinema")[0].children);
	const lnb_lnb = Array.from(document.getElementsByClassName("header-lnb-lnb")[0].children);
	const lnb_lnb_background = document.getElementsByClassName("header-lnb-lnb")[0];
	
	lnb_cinema.forEach((lnb_cinema_li, lnb_cinema_idx) => {
		lnb_cinema_li.addEventListener("mouseover", () => {
			lnb_lnb_background.style.display = "block";
			
			lnb_lnb.forEach((lnb_lnb_li, lnb_lnb_idx) => {
				if(lnb_cinema_idx === lnb_lnb_idx){
					lnb_lnb_li.style.display = "flex";
					if(lnb_cinema_idx === 1 || lnb_cinema_idx === 6){
						lnb_lnb_background.style.height = "62px";
						lnb_lnb_li.style.marginTop = "12px";
					}else if(lnb_cinema_idx === 2){
						lnb_lnb_background.style.height = "96px";
						lnb_lnb_li.style.marginTop = "12px";
					}else{
						lnb_lnb_background.style.height = "38px";
						lnb_lnb_li.style.marginTop = "0";
					}
				}else{
					lnb_lnb_li.style.display = "none";
				}
			})
		});
		
		lnb_lnb_background.addEventListener("mouseover", () => {
			lnb_background.style.display = "block";
			lnb_lnb_background.style.display = "block";
		})
		
		lnb_cinema_li.addEventListener("mouseout", () => {
			lnb_background.style.display = "none";
			lnb_lnb_background.style.display = "none";
		});
		
		lnb_lnb_background.addEventListener("mouseout", () => {
			lnb_background.style.display = "none";
			lnb_lnb_background.style.display = "none";
		})
	});
	// ------ end ------
	
	// ------ 스크롤 시 헤더 변경 메서드 ------
    document.addEventListener("scroll", () => {
		const scroll = document.documentElement.scrollTop;
		const header_container = document.getElementsByClassName("header-container")[0];
		const header_bottom = document.getElementsByClassName("header-bottom")[0];
		const header_gnb_list = document.getElementsByClassName("header-gnb-list")[0];
			
		// 스크롤을 내렸을 때 헤더 디자인 변경
		if(scroll > 60){
			document.getElementsByClassName("header-top")[0].style.display = "none";
			header_container.classList.add("header-container-invert");
			header_bottom.classList.add("header-bottom-invert");
			// lnb도 fixed로 해서 gnb 밑으로 이동
			lnb_background.classList.add("header-lnb-fixed-invert");
			header_gnb_list.classList.add("header-gnb-list-invert");
			lnb_lnb_background.classList.add("header-lnb-lnb-fixed-invert");
		// 스크롤을 올렸을 때 헤더 디자인 복구
		}else{
			document.getElementsByClassName("header-top")[0].style.display = "flex";
			header_container.classList.remove("header-container-invert");
			header_bottom.classList.remove("header-bottom-invert");
			lnb_background.classList.remove("header-lnb-fixed-invert");
			header_gnb_list.classList.remove("header-gnb-list-invert");
			lnb_lnb_background.classList.remove("header-lnb-lnb-fixed-invert");
		}
	})
	// ------ end ------
	
	// ------ 메인 스페셜관 영상 관련 메서드 ------
	// 선택한 요소들을 변수에 저장
	const content_list = Array.from(document.getElementsByClassName("main-special-list-contents")[0].children);
	const media_list = Array.from(document.getElementsByClassName("main-special-content-media")[0].children);
	
	// 페이지 로드 시 idx 0번을 기본값으로 설정
	media_list.forEach((media_li, media_idx) => {
		if(media_idx !== 0){
			media_li.style.display = "none";
		}
	})
	
	// content_list의 li 요소에 클릭 이벤트 리스너 추가
	content_list.forEach((content_li, content_idx) => {
	    content_li.addEventListener("click", () => {
	        // 모든 content_li 요소의 스타일 초기화
	        content_list.forEach(content_li => {
	            content_li.style.border = "none";
	            content_li.style.borderRadius = "none";
	        });
	        
	        // 클릭한 li 요소의 인덱스를 사용하여 media_list의 li 요소를 조작
	        media_list.forEach((media_li, media_idx) => {
	            if (media_idx === content_idx) {
	                // 해당 인덱스의 media_list li 요소를 표시
	                media_li.style.display = "block";
	                // 클릭한 content_li의 스타일 변경
	                content_li.style.border = "2px solid #d8dee8";
	                content_li.style.borderRadius = "8px";
	            } else {
	                // 나머지 media_list li 요소는 숨김
	                media_li.style.display = "none";
	            }
	        });
	    });
	});
	// ------ end ------
});
