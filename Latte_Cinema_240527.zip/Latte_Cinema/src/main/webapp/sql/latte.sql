-- 회사 정보 테이블
create table company(
	company_business_no varchar(50) primary key,		-- 사업자 번호
    company_name varchar(50) not null,					-- 회사명
    company_ceo_name varchar(50) not null,				-- 대표자
    company_address varchar(500) not null,				-- 주소
    company_phone varchar(50) not null,					-- 전화번호
    company_anniversary date not null					-- 설립일
);

-- 관리자 정보 테이블
create table admin(
	admin_no varchar(50) primary key,					-- 관리자 번호
    admin_id varchar(50) not null,						-- 관리자 ID
    admin_pwd varchar(50) not null,						-- 관리자 비밀번호
    admin_name varchar(50) not null,					-- 관리자 이름
    admin_job varchar(50) not null,						-- 직책
    admin_phone varchar(50) not null					-- 전화번호
);

-- 회원 정보 테이블
create table member(
	member_no varchar(50) primary key,					-- 회원 번호
    member_id varchar(50) not null,						-- 회원 ID
    member_pwd varchar(50) not null,					-- 회원 비밀번호
    member_name varchar(50) not null,					-- 회원 이름
    member_phone varchar(50) not null,					-- 전화번호
    member_email varchar(50),							-- 이메일
    member_mileage int default 0,						-- 마일리지
    member_grade varchar(50) default "VIP", 			-- 등급
    member_signup_date datetime default now()			-- 가입일
);

-- 영화 정보 테이블
create table movie(
	movie_no int primary key,							-- 영화 번호
    movie_title varchar(500) not null,					-- 영화 이름
    movie_genre varchar(50) not null,					-- 장르
    movie_screen_time int not null,						-- 상영 시간
    movie_director varchar(50) not null,				-- 감독
    movie_actor varchar(50) not null,					-- 주연 배우
    movie_release_date date not null,					-- 개봉일
    movie_poster varchar(2000) not null,				-- 포스터(사진)
    movie_price int not null default 15000				-- 가격
);

-- 상영 정보 테이블
create table screening(
	screening_no int primary key,						-- 상영 정보 고유 번호
    screening_region varchar(50) not null,				-- 상영 지역
    screening_location varchar(50) not null,			-- 상영 지점
    screening_movie_no int not null,					-- 영화 번호
    screening_movie_title varchar(500) not null,		-- 영화 이름
    screening_movie_start_date date not null,			-- 영화 시작 날짜
    screening_movie_start_time time not null,			-- 영화 시작 시간
    screening_hall int not null,						-- 상영관
    screening_seat_status boolean not null default true	-- 좌석 유무
);

-- 상영 정보의 좌석 정보 테이블
create table seat(
	seat_no int primary key,							-- 상영 정보 고유 번호(참조)
    seat_booking_count int,								-- 좌석 선택 수
    seat_booking_status varchar(2000),					-- 좌석 예약 상태
    
    foreign key (seat_no) references screening (screening_no) on update cascade
);

-- 예매 내역 테이블
create table ticketing_history(
	ticketing_history_no int primary key,							-- 예매 내역 번호
    ticketing_history_member_no varchar(50) not null,				-- 예매자 번호
    ticketing_history_movie_no varchar(50) not null,				-- 영화 번호
    ticketing_history_movie_title varchar(500) not null,			-- 영화 이름
    ticketing_history_movie_start_date date not null,				-- 영화 시작 날짜
    ticketing_history_movie_start_time time not null,				-- 영화 시작 시간
    ticketing_history_payment_amount int not null,					-- 결제 금액
    ticketing_history_payment_method varchar(50) not null,			-- 결제 방식
    ticketing_history_booking_count int not null,					-- 예매 수량
    ticketing_history_booking_date datetime not null default now()	-- 예매 일시
);

-- 상영 후기 테이블
create table movie_review(
	movie_review_no int primary key,						-- 상영 후기 글번호
    movie_review_writer_no varchar(50) not null,			-- 작성자 번호
    movie_review_writer_id varchar(50) not null,			-- 작성자 ID
    movie_review_movie_no int not null,						-- 영화 번호
    movie_review_movie_title varchar(500) not null,			-- 영화 이름
    movie_review_content varchar(2000) not null,			-- 후기 내용
    movie_review_created_date datetime default now()		-- 작성 일시
);

-- 이벤트 게시판 테이블
create table event_board(
	event_board_no int primary key,							-- 이벤트 글번호
    event_board_writer_no varchar(50) not null,				-- 작성자 이름(관리자)
    event_board_writer_id varchar(50) not null,				-- 작성자 ID
    event_board_title varchar(500) not null,				-- 글 제목
    event_board_content varchar(2000) not null,				-- 글 내용
	event_board_file varchar(2000),							-- 첨부 파일
    event_board_created_date datetime default now(),		-- 작성 일시
    event_board_updated_date datetime,						-- 수정 일시
    event_board_hit int default 0							-- 조회수
);
 -- 공지사항 게시판 테이블
create table notice_board(
	notice_board_no int primary key,						-- 공지사항 글번호
    notice_board_writer_no varchar(50) not null,			-- 작성자 이름(관리자)
    notice_board_writer_id varchar(50) not null,			-- 작성자 ID
    notice_board_title varchar(500) not null,				-- 글 제목
    notice_board_content varchar(2000) not null,			-- 글 내용
	notice_board_file varchar(2000),						-- 첨부 파일
    notice_board_created_date datetime default now(),		-- 작성 일시
    notice_board_updated_date datetime,						-- 수정 일시
    notice_board_hit int default 0							-- 조회수
);

-- 문의 내역 테이블
create table inquiry_history(
	inquiry_history_no int primary key,						-- 문의 내역 글번호
    inquiry_history_writer_no varchar(50) not null,			-- 작성자 이름(회원)
    inquiry_history_writer_id varchar(50) not null,			-- 작성자 ID
    inquiry_history_type varchar(50) not null,				-- 문의 유형
    inquiry_history_title varchar(500) not null,			-- 글 제목
    inquiry_history_content varchar(2000) not null,			-- 글 내용
	inquiry_history_file varchar(2000),						-- 첨부 파일
    inquiry_history_created_date datetime default now()		-- 작성 일시
);