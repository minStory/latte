// ------------ 메인페이지 배경이미지 자동 변경 메서드 ------------
let idx = 1; // 시작 이미지 번호
const img_count = 4; // 총 이미지 개수
const second = 5000; // 이미지를 유지할 시간(millisecond)

// ------ 다음 이미지로 변경 ------
function showNextImage() {
	const header_image = document.getElementsByClassName("header-image")[0];
    
    // 현재 이미지 제거
    header_image.classList.remove(`header-bg${idx}`);
    
    idx++;
    if (idx > img_count) {
        idx = 1;
    }
    // 다음 이미지 추가
    header_image.classList.add(`header-bg${idx}`);
    
    // 조건 만족 시 함수 종료
    if (idx > img_count) {
        idx = 1;
        return true;
    }
}
// ------ end ------

// ------ 이전 이미지로 변경 ------
function showPreviousImage(){
	const header_image = document.getElementsByClassName("header-image")[0];
    
    // 현재 이미지 제거
    header_image.classList.remove(`header-bg${idx}`);
    
    idx--;
    if (idx < 1) {
        idx = img_count;
    }
    // 이전 이미지 추가
    header_image.classList.add(`header-bg${idx}`);
    
    // 조건 만족 시 함수 종료
    if (idx < 1) {
        idx = img_count;
        return true;
    }
}
// ------ end ------

// ------ 타이머 함수 ------
function timer() {
    let interval = setInterval(() => {
        showNextImage();
    }, second);
}
// ------ end ------

// 타이머 실행
timer();
// ------ end ------
// ------------ 메인페이지 배경이미지 자동 변경 메서드 영역 end ------------



// ------ 회원가입 시 두 비밀번호가 일치하는지 확인하는 메서드 ------
function validatePwd(){
	if(myForm.pwd.value !== myForm.pwd_check.value){
		alert("비밀번호를 확인해주세요!");
		return false;
	}
}
// ------ end ------



// ------ 로그아웃 버튼을 클릭하면 확인창을 표시할 메서드 ------
function confirmLogout() {
    if (confirm("로그아웃하시겠습니까?")) {
        window.location.href = "logout";
    } else {
        return false;
    }
}
// ------ end ------