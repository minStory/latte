package com.cinema.model;

public class CompanyDTO {
	
	private String company_business_no;
	private String company_name;
	private String company_ceo_name;
	private String company_address;
	private String company_phone;
	private String company_anniversary;
	
	public String getCompany_business_no() {
		return company_business_no;
	}
	public void setCompany_business_no(String company_business_no) {
		this.company_business_no = company_business_no;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getCompany_ceo_name() {
		return company_ceo_name;
	}
	public void setCompany_ceo_name(String company_ceo_name) {
		this.company_ceo_name = company_ceo_name;
	}
	public String getCompany_address() {
		return company_address;
	}
	public void setCompany_address(String company_address) {
		this.company_address = company_address;
	}
	public String getCompany_phone() {
		return company_phone;
	}
	public void setCompany_phone(String company_phone) {
		this.company_phone = company_phone;
	}
	public String getCompany_anniversary() {
		return company_anniversary;
	}
	public void setCompany_anniversary(String company_anniversary) {
		this.company_anniversary = company_anniversary;
	}
}