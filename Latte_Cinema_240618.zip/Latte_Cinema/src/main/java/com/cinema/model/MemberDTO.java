package com.cinema.model;

public class MemberDTO {
	
	private String member_no;
	private String member_id;
	private String member_pwd;
	private String member_name;
	private String member_phone;
	private String member_email;
	private int member_mileage;
	private String member_grade;
	private String member_signup_date;
	
	public String getMember_no() {
		return member_no;
	}
	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getMember_pwd() {
		return member_pwd;
	}
	public void setMember_pwd(String member_pwd) {
		this.member_pwd = member_pwd;
	}
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getMember_phone() {
		return member_phone;
	}
	public void setMember_phone(String member_phone) {
		this.member_phone = member_phone;
	}
	public String getMember_email() {
		return member_email;
	}
	public void setMember_email(String member_email) {
		this.member_email = member_email;
	}
	public int getMember_mileage() {
		return member_mileage;
	}
	public void setMember_mileage(int member_mileage) {
		this.member_mileage = member_mileage;
	}
	public String getMember_grade() {
		return member_grade;
	}
	public void setMember_grade(String member_grade) {
		this.member_grade = member_grade;
	}
	public String getMember_signup_date() {
		return member_signup_date;
	}
	public void setMember_signup_date(String member_signup_date) {
		this.member_signup_date = member_signup_date;
	}
}
