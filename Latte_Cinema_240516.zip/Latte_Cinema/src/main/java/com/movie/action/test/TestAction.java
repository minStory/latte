package com.movie.action.test;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.movie.action.Action;
import com.movie.action.ActionForward;

public class TestAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/public/test/test.jsp");

		return forward;
	}

}
