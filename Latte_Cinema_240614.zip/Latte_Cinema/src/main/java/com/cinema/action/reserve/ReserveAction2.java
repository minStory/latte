package com.cinema.action.reserve;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cinema.action.Action;
import com.cinema.action.ActionForward;
import com.cinema.action.StaticArea;

public class ReserveAction2 implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setAttribute("localList", StaticArea.localList);
		request.setAttribute("seoulList", StaticArea.seoulList);
		request.setAttribute("gyeonggiIncheonList", StaticArea.gyeonggiIncheonList);
		request.setAttribute("chungCheongDaeJeonList", StaticArea.chungCheongDaeJeonList);
		request.setAttribute("jeollaGwangjuList", StaticArea.jeollaGwangjuList);
		request.setAttribute("gyeongbukDaeguList", StaticArea.gyeongbukDaeguList);
		request.setAttribute("gyeongnamBusanUlsanList", StaticArea.gyeongnamBusanUlsanList);
		request.setAttribute("gangwonList", StaticArea.gangwonList);
		request.setAttribute("jejuList", StaticArea.jejuList);
		request.setAttribute("sizeList", StaticArea.sizeList);

		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/public/reserve/reserve2.jsp");

		return forward;
	}

}
