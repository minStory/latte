// 페이지 로드 시 실행되는 코드
document.addEventListener("DOMContentLoaded", () => {
	
	// ------ 메인페이지를 제외한 페이지 헤더 디자인 변경 ------
	if(!window.location.href.includes("main")){
		const header = document.getElementById("header");
		const header_image = document.getElementById("header-image");
		const header_background = document.getElementById("header-background");
		const header_bottom_background = document.getElementById("header-bottom-background");
		const header_top = document.getElementById("header-top");
		const header_top_logo = document.getElementById("header-top-logo");
		const header_lnb = document.getElementById("header-lnb");
		const btn_facebook = document.getElementById("btn-facebook");
		const btn_youtube = document.getElementById("btn-youtube");
		const btn_instagram = document.getElementById("btn-instagram");
		const btn_signup = document.getElementById("btn-signup");
		const btn_reserve = document.getElementById("btn-reserve");
		
		header.classList.add("header-invert");
		header_image.classList.add("header-image-invert");
		header_background.classList.add("header-background-invert");
		header_bottom_background.classList.add("header-bottom-background-invert");
		header_top.classList.add("header-top-invert");
		header_lnb.classList.add("header-lnb-invert");
		btn_facebook.classList.add("btn-facebook-invert");
		btn_youtube.classList.add("btn-youtube-invert");
		btn_instagram.classList.add("btn-instagram-invert");
		btn_signup.classList.add("btn-signup-invert");
		btn_reserve.classList.add("btn-reserve-invert");
		header_top_logo.classList.add("header-top-logo-invert");
	}
	// ------ end ------
	
	// ------ 헤더의 lnb를 표시하는 메서드 ------
	const gnb = Array.from(document.getElementsByClassName("header-gnb-list")[0].children);
	const lnb = Array.from(document.getElementsByClassName("header-lnb")[0].children)
	const lnb_background = document.getElementsByClassName("header-lnb")[0];
	
	gnb.forEach((gnb_li, gnb_idx) => {
		gnb_li.addEventListener("mouseover", () => {
			lnb_background.style.display = "block";
			
			lnb.forEach((lnb_li, lnb_idx) => {
				if(gnb_idx === lnb_idx){
					lnb_li.style.display = "flex";
				}else{
					lnb_li.style.display = "none";
				}
			})
		})
	    lnb_background.addEventListener("mouseover", () => {
	        lnb_background.style.display = "block";
	    });
	
	    lnb.forEach((lnb_li) => {
	        lnb_li.addEventListener("mouseout", () => {
	            lnb_background.style.display = "none";
	        });
	    });
	
	    // 마우스를 뗄 때 lnb_background의 display를 none으로 설정
	    gnb_li.addEventListener("mouseout", () => {
	        lnb_background.style.display = "none";
	    });
	});
	// ------ end ------
	
	// ------ 스크롤 시 헤더 변경 메서드 ------
    document.addEventListener("scroll", () => {
		const scroll = document.documentElement.scrollTop;
		const header_container = document.getElementById("header-container");
		const header_bottom = document.getElementById("header-bottom");
		const header_gnb_list = document.getElementById("header-gnb-list");
			
		// 스크롤을 내렸을 때 헤더 디자인 변경
		if(scroll > 60){
			document.getElementById("header-top").style.display = "none";
			header_container.classList.add("header-container-invert");
			header_bottom.classList.add("header-bottom-invert");
			// lnb도 fixed로 해서 gnb 밑으로 이동
			lnb_background.classList.add("header-lnb-fixed-invert");
			header_gnb_list.classList.add("header-gnb-list-invert");
		// 스크롤을 올렸을 때 헤더 디자인 복구
		}else{
			document.getElementById("header-top").style.display = "flex";
			header_container.classList.remove("header-container-invert");
			header_bottom.classList.remove("header-bottom-invert");
			lnb_background.classList.remove("header-lnb-fixed-invert");
			header_gnb_list.classList.remove("header-gnb-list-invert");
		}
	})
	// ------ end ------
	
	// ------ 메인 스페셜관 영상 관련 메서드 ------
	// 선택한 요소들을 변수에 저장 (querySelectorAll or getElementsByClassName)
	//const content_list = document.querySelectorAll(".main-special-list-contents li");
	//const media_list = document.querySelectorAll(".main-special-content-media li");
	const content_list = Array.from(document.getElementsByClassName("main-special-list-contents")[0].children);
	const media_list = Array.from(document.getElementsByClassName("main-special-content-media")[0].children);
	
	// 페이지 로드 시 idx 0번을 기본값으로 설정
	media_list.forEach((media_li, media_idx) => {
		if(media_idx !== 0){
			media_li.style.display = "none";
		}
	})
	
	// content_list의 li 요소에 클릭 이벤트 리스너 추가
	content_list.forEach((content_li, content_idx) => {
	    content_li.addEventListener("click", () => {
	        // 모든 content_li 요소의 스타일 초기화
	        content_list.forEach(content_li => {
	            content_li.style.border = "none";
	            content_li.style.borderRadius = "none";
	        });
	        
	        // 클릭한 li 요소의 인덱스를 사용하여 media_list의 li 요소를 조작
	        media_list.forEach((media_li, media_idx) => {
	            if (media_idx === content_idx) {
	                // 해당 인덱스의 media_list li 요소를 표시
	                media_li.style.display = "block";
	                // 클릭한 content_li의 스타일 변경
	                content_li.style.border = "2px solid #d8dee8";
	                content_li.style.borderRadius = "8px";
	            } else {
	                // 나머지 media_list li 요소는 숨김
	                media_li.style.display = "none";
	            }
	        });
	    });
	});
	// ------ end ------
});
