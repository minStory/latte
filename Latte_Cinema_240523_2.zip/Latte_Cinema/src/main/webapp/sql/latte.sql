create table movie(
	movie_no int primary key,
    movie_name varchar(50),
    movie_genre varchar(50),    
    movie_actor varchar(50),
    movie_director varchar(50),
    movie_release_date date default now()
);