package com.cinema.action.session;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;

import com.cinema.action.Action;
import com.cinema.action.ActionForward;

public class ExpiredSessionAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = null;

		if (request.getSession(false) != null) {
			session = request.getSession(false);

			long creationTime = session.getCreationTime(); // 세션 생성 시간
			int maxInactiveInterval = session.getMaxInactiveInterval(); // 세션 유효 시간 (초)
			long currentTime = System.currentTimeMillis(); // 현재 시간
			long elapsedTime = currentTime - creationTime; // 세션 경과 시간
			long remainingTime = maxInactiveInterval - TimeUnit.MILLISECONDS.toSeconds(elapsedTime); // 남은 시간 (초)
			long remainingHour = remainingTime / 60 < 10 ? remainingTime / 60 : remainingTime / 60;
			long remainingMinute = remainingTime % 60 < 10 ? remainingTime % 60 : remainingTime % 60;

			if (remainingHour == 0 && remainingMinute == 0) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("expiredSession", "logout");

				PrintWriter w = response.getWriter();
				w.write(jsonObject.toJSONString());
				w.close();
			}
		}

		return null;
	}
}