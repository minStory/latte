package com.cinema.action.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cinema.action.Action;
import com.cinema.action.ActionForward;
import com.cinema.model.LatteDAO;

public class AdminDeleteOkMovieAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		System.out.println("ddd");
		int nowNo = Integer.parseInt(request.getParameter("NowNo").trim());
		//int planNo = Integer.parseInt(request.getParameter("PlanNo").trim());

		LatteDAO dao = LatteDAO.getInstance();

		int NowCheck = dao.AdminDeleteNowMovie(nowNo);
		//int PlanCheck = dao.AdminDeletePlanMovie(planNo);
		
		System.out.println(NowCheck);
		//System.out.println(PlanCheck);
		PrintWriter out = response.getWriter();

		if (NowCheck > 0) {
			out.println("<script>");
			out.println("alert('영화 삭제 성공')");
			out.println("location.href='movie_list'");
			out.println("</script>");
			out.close();
		} else {
			out.println("<script>");
			out.println("alert('영화 삭제 실패')");
			out.println("history.back()");
			out.println("</script>");
			out.close();
		}
//		if (PlanCheck > 0) {
//			out.println("<script>");
//			out.println("alert('영화 삭제 성공')");
//			out.println("location.href='movie_list'");
//			out.println("</script>");
//			out.close();
//		} else {
//			out.println("<script>");
//			out.println("alert('영화 삭제 실패')");
//			out.println("history.back()");
//			out.println("</script>");
//			out.close();
//		}
		return null;
	}

}
