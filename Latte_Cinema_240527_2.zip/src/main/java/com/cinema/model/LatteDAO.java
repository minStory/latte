package com.cinema.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cinema.model.LatteDAO;

public class LatteDAO {

	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";

	private static LatteDAO instance = null;

	private LatteDAO() {
	}

	public static LatteDAO getInstance() {

		if (instance == null) {
			instance = new LatteDAO();
		}

		return instance;
	}

	public void openConn() {

		try {
			Context initCtx = new InitialContext();
			Context ctx = (Context) initCtx.lookup("java:comp/env");
			DataSource ds = (DataSource) ctx.lookup("jdbc/mysql");
			con = ds.getConnection();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void closeConn(ResultSet rs, PreparedStatement pstmt, Connection con) {

		try {

			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void closeConn(PreparedStatement pstmt, Connection con) {

		try {

			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 회원가입 메서드
	public int insertMember(MemberDTO dto) {

		int result = 0;

		int count = 0;

		try {
			openConn();

			sql = "select count(*) from member";

			pstmt = con.prepareStatement(sql);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1) + 1;
			}

			// 회원번호 M20240527001, M20240527010, M20240527100 과 같이
			// 맨 뒤의 3자리를 맞추기 위한 코드
			if (count < 100) {
				dto.setMember_no(dto.getMember_no() + "0");
			}

			if (count < 10) {
				dto.setMember_no(dto.getMember_no() + "0");
			}

			dto.setMember_no(dto.getMember_no() + count);

			sql = "insert into member values(?, ?, ?, ?, ?, ?, default, default, default)";

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getMember_no());
			pstmt.setString(2, dto.getMember_id());
			pstmt.setString(3, dto.getMember_pwd());
			pstmt.setString(4, dto.getMember_name());
			pstmt.setString(5, dto.getMember_phone());
			pstmt.setString(6, dto.getMember_email());

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}

		return result;
	}

	// 회원 로그인 시 id와 pwd를 검증하는 메서드
	public int checkMemberLogin(MemberDTO dto) {

		int result = 0;

		try {
			openConn();

			sql = "select * from member where member_id = ?";

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getMember_id());

			rs = pstmt.executeQuery();

			if (rs.next()) {
				if (rs.getString("member_pwd").equals(dto.getMember_pwd())) {
					result = 1;
				} else {
					result = 0;
				}
			} else {
				result = -1;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}

		return result;
	}

	// 검증된 회원의 id로 모든 데이터를 조회하는 메서드
	public MemberDTO getMemberInfo(String id) {

		MemberDTO dto = null;

		try {
			openConn();

			sql = "select * from member where member_id = ?";

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				dto = new MemberDTO();
				dto.setMember_no(rs.getString("member_no"));
				dto.setMember_id(rs.getString("member_id"));
				dto.setMember_pwd(rs.getString("member_pwd"));
				dto.setMember_name(rs.getString("member_name"));
				dto.setMember_phone(rs.getString("member_phone"));
				dto.setMember_email(rs.getString("member_email"));
				dto.setMember_mileage(rs.getInt("member_mileage"));
				dto.setMember_grade(rs.getString("member_grade"));
				dto.setMember_signup_date(rs.getString("member_signup_date"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}

		return dto;
	}

	// 로그인 아이디가 관리자 계정에 속하는지 확인하는 메서드
	public boolean checkBelongToAdmin(String id) {

		boolean result = false;

		try {
			openConn();

			sql = "select * from admin where admin_id = ?";

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();

			if (rs.next()) {
				result = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}

		return result;
	}

	// 관리자 로그인 시 id와 pwd를 검증하는 메서드
	public int checkAdminLogin(AdminDTO dto) {

		int result = 0;

		try {
			openConn();

			sql = "select * from admin where admin_id = ?";

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getAdmin_id());

			rs = pstmt.executeQuery();

			if (rs.next()) {
				if (rs.getString("admin_pwd").equals(dto.getAdmin_pwd())) {
					result = 1;
				} else {
					result = 0;
				}
			} else {
				result = -1;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}

		return result;
	}

	// 검증된 관리자의 id로 모든 데이터를 조회하는 메서드
	public AdminDTO getAdminInfo(String id) {

		AdminDTO dto = null;

		try {
			openConn();

			sql = "select * from admin where admin_id = ?";

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				dto = new AdminDTO();
				dto.setAdmin_no(rs.getString("admin_no"));
				dto.setAdmin_id(rs.getString("admin_id"));
				dto.setAdmin_pwd(rs.getString("admin_pwd"));
				dto.setAdmin_name(rs.getString("admin_name"));
				dto.setAdmin_job(rs.getString("admin_job"));
				dto.setAdmin_phone(rs.getString("admin_phone"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}

		return dto;
	}
}
